#!/usr/bin/env python3
"""Proof-only auxiliary renderer exercise for four real Warder assets.

This is deliberately not wired into production. It reuses the production
fit_logo geometry and contrast primitives, then adds topology-based local-panel
handling for this proof. No identity/name is used to decide rendering.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

HERE = Path(__file__).resolve().parent
INPUT = Path('/tmp/aux-proof-refresh/pngs')
ENGINE_PATH = Path('/workspace/scratch/6fb58f2ea1eb/PiconHub-Warder-Evolution/tools/rebuild_master_catalog.py')
TEMPLATE_DIR = Path('/workspace/scratch/6fb58f2ea1eb/templates/picons')
SIZE = (220, 132)
COMMIT = 'db5eec9f1cdb7a4d587cb1bcdeebc6b3f0d51819'
SAFE_TREE = 'reports/warder-master-production/auxiliary-publishability-gate-2026-10-07/safe-candidate-tree/provider'

spec = importlib.util.spec_from_file_location('warder_production_engine', ENGINE_PATH)
engine = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = engine
assert spec.loader
spec.loader.exec_module(engine)

CASES = [
    ('A_DARK_WORDMARK', 'TV8.png'),
    ('B_LIGHT_WORDMARK', '7+ CHANNEL.png'),
    ('C_MIXED_COLOR_TEXT', 'CCTV.png'),
    ('D_BADGE_PANEL', 'CBC.png'),
]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def lum(rgb: np.ndarray) -> np.ndarray:
    x = rgb.astype(np.float32) / 255.0
    x = np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4)
    return x[..., 0] * .2126 + x[..., 1] * .7152 + x[..., 2] * .0722


def contrast(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    la, lb = lum(a), lum(b)
    hi, lo = np.maximum(la, lb), np.minimum(la, lb)
    return (hi + .05) / (lo + .05)


def bbox(mask: np.ndarray) -> list[int] | None:
    ys, xs = np.nonzero(mask)
    if not len(xs):
        return None
    return [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]


def labels(mask: np.ndarray) -> tuple[np.ndarray, int]:
    return ndimage.label(mask, structure=np.ones((3, 3), dtype=np.uint8))


def underlay(master: np.ndarray) -> np.ndarray:
    alpha = master[..., 3:4].astype(np.float32) / 255.0
    return np.rint(master[..., :3].astype(np.float32) * alpha).astype(np.uint8)


def topology_panels(src: np.ndarray) -> tuple[list[dict], list[dict]]:
    """Find framed local fields and negative glyph cutouts from alpha topology.

    Candidate fields must be enclosed alpha holes that are large relative to a
    large, achromatic enclosing component and contain separate positive artwork.
    Smaller enclosed holes nested in the same panel are treated as cutout glyphs.
    """
    alpha = src[..., 3]
    visible = alpha > 0
    fg_labels, nfg = labels(visible)
    # fit_logo's LANCZOS edge ringing can leave low-alpha pixels inside a
    # transparent cutout; classify those as the same geometric void rather
    # than splitting one panel into several narrow residual strips.
    void_labels, nvoid = labels(alpha < 16)
    border_ids = set(void_labels[0, :].tolist()) | set(void_labels[-1, :].tolist()) | set(void_labels[:, 0].tolist()) | set(void_labels[:, -1].tolist())
    h, w = alpha.shape
    panel_records: list[dict] = []
    cutout_records: list[dict] = []
    used_panel_holes: set[int] = set()

    for fg_id in range(1, nfg + 1):
        frame = fg_labels == fg_id
        fb = bbox(frame)
        if not fb:
            continue
        fx0, fy0, fx1, fy1 = fb
        farea = int(frame.sum())
        fbox_area = max(1, (fx1 - fx0) * (fy1 - fy0))
        if farea < max(700, int(.08 * w * h)) or farea / fbox_area < .30:
            continue
        frame_rgb = src[..., :3][frame & (alpha >= 128)]
        if not len(frame_rgb):
            continue
        frame_delta = frame_rgb.max(axis=1).astype(int) - frame_rgb.min(axis=1).astype(int)
        if float(np.mean(frame_delta <= engine.ACHROMATIC_DELTA)) < .97:
            continue

        enclosed: list[tuple[int, np.ndarray, list[int], int]] = []
        for hole_id in range(1, nvoid + 1):
            if hole_id in border_ids:
                continue
            hole = void_labels == hole_id
            hb = bbox(hole)
            if not hb:
                continue
            hx0, hy0, hx1, hy1 = hb
            if hx0 < fx0 or hy0 < fy0 or hx1 > fx1 or hy1 > fy1:
                continue
            # The candidate is geometrically enclosed by the larger achromatic
            # component; the hole boundary must contact that component.
            dil = ndimage.binary_dilation(hole, structure=np.ones((3, 3), dtype=bool))
            if int(np.count_nonzero(dil & frame)) < max(20, int(.01 * np.count_nonzero(dil))):
                continue
            enclosed.append((hole_id, hole, hb, int(hole.sum())))
        if not enclosed:
            continue

        # A true subpanel occupies a substantial region and has at least one
        # disconnected positive component inside it. Small holes are glyph
        # counters/cutouts, never panel backgrounds.
        for hole_id, hole, hb, area in enclosed:
            hx0, hy0, hx1, hy1 = hb
            ratio = area / fbox_area
            if ratio < .10 or (hx1 - hx0) < .18 * (fx1 - fx0) or (hy1 - hy0) < .35 * (fy1 - fy0):
                continue
            inside_ids = set(np.unique(fg_labels[hole])) - {0, fg_id}
            inside = []
            for iid in inside_ids:
                comp = fg_labels == iid
                pix = src[..., :3][comp & (alpha >= 128)]
                if len(pix) >= 8:
                    inside.append((iid, comp, pix))
            if not inside:
                continue
            # An ambiguous multicolor field is deliberately not transformed.
            foreground = np.concatenate([entry[2] for entry in inside], axis=0)
            delta = foreground.max(axis=1).astype(int) - foreground.min(axis=1).astype(int)
            ach_fraction = float(np.mean(delta <= engine.ACHROMATIC_DELTA))
            if ach_fraction < .97:
                continue
            fg_luma = float(np.median(lum(foreground)))
            if .35 < fg_luma < .65:
                continue
            panel_target = [16, 16, 16] if fg_luma >= .65 else [240, 240, 240]
            panel_records.append({
                'enclosing_component_id': int(fg_id), 'panel_hole_id': int(hole_id),
                'bbox_xyxy_exclusive': hb, 'area': area, 'enclosure_bbox': fb,
                'positive_components_inside': [int(x[0]) for x in inside],
                'foreground_luma_median': fg_luma, 'foreground_achromatic_fraction': ach_fraction,
                'panel_fill_rgb': panel_target,
                'rule': 'large enclosed alpha field within achromatic framed component; local background selected to contrast contained positive glyphs',
            })
            used_panel_holes.add(hole_id)

        # Smaller enclosed zero-alpha islands are treated as glyph cutouts
        # only when this same enclosing component has a separately established
        # large local panel hole. Without that panel evidence they remain normal
        # letter counters (for example the counters of an 8 or O).
        has_panel = any(x['enclosing_component_id'] == int(fg_id) for x in panel_records)
        if not has_panel:
            continue
        for hole_id, hole, hb, area in enclosed:
            if hole_id in used_panel_holes or area < 16 or area / fbox_area >= .10:
                continue
            hx0, hy0, hx1, hy1 = hb
            # Restrict to the dense panel body, away from the thin enclosing rim.
            interior_frame = frame.copy()
            ymargin = max(2, int(.025 * (fy1 - fy0)))
            xmargin = max(2, int(.025 * (fx1 - fx0)))
            if hx0 < fx0 + xmargin or hx1 > fx1 - xmargin or hy0 < fy0 + ymargin or hy1 > fy1 - ymargin:
                continue
            local = src[..., :3][frame & (alpha >= 128)]
            if not len(local):
                continue
            local_med = np.median(local, axis=0).astype(np.uint8)
            # Choose a deterministic achromatic ink with strong contrast against
            # the existing panel color; no source hue is changed.
            ink = [16, 16, 16] if float(lum(local_med.reshape(1, 1, 3))[0, 0]) >= .5 else [240, 240, 240]
            cutout_records.append({
                'enclosing_component_id': int(fg_id), 'hole_id': int(hole_id),
                'bbox_xyxy_exclusive': hb, 'area': area, 'ink_rgb': ink,
                'rule': 'small enclosed alpha cutout nested in a broad panel; render as foreground glyph with contrast against local panel',
            })
    return panel_records, cutout_records


def logical_groups(masks: list[np.ndarray]) -> list[list[int]]:
    boxes = [bbox(mask) for mask in masks]
    parent = list(range(len(masks)))
    def root(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    def union(a: int, b: int) -> None:
        ra, rb = root(a), root(b)
        if ra != rb:
            parent[rb] = ra
    heights = [b[3] - b[1] for b in boxes if b]
    typical = float(np.median(heights)) if heights else 1.0
    for i, a in enumerate(boxes):
        if not a:
            continue
        for j in range(i + 1, len(boxes)):
            b = boxes[j]
            if not b:
                continue
            overlap = max(0, min(a[3], b[3]) - max(a[1], b[1]))
            gap = max(0, max(a[0], b[0]) - min(a[2], b[2]))
            same_baseline = abs(a[3] - b[3]) <= max(2, .12 * typical)
            if (overlap >= .45 * min(a[3]-a[1], b[3]-b[1]) or same_baseline) and gap <= .75 * typical:
                union(i, j)
    groups: dict[int, list[int]] = {}
    for i in range(len(masks)):
        groups.setdefault(root(i), []).append(i)
    return list(groups.values())


def render(source: Image.Image, master_img: Image.Image, style: str) -> tuple[Image.Image, dict]:
    fitted, scale, original_bbox = engine.fit_logo(source)
    src = np.asarray(fitted, dtype=np.uint8)
    work = src.copy()
    alpha = src[..., 3]
    visible = alpha > 0
    solid = alpha >= engine.OPAQUE_ALPHA
    master = np.asarray(master_img, dtype=np.uint8)
    master_bg = underlay(master)
    panel_info, cutout_info = topology_panels(src)
    protected = np.zeros(alpha.shape, dtype=bool)
    local_masks: list[np.ndarray] = []

    # Keep panel geometry fixed. The panel hole is already bounded by the
    # source frame; only its fill color is set from the contained glyph polarity.
    for rec in panel_info:
        hole = np.zeros(alpha.shape, dtype=bool)
        hx0, hy0, hx1, hy1 = rec['bbox_xyxy_exclusive']
        # Recover exact hole pixels by the component id; no rectangular mask.
        vl, _ = labels(alpha < 16)
        hole = vl == rec['panel_hole_id']
        work[..., :3][hole] = rec['panel_fill_rgb']
        work[..., 3][hole] = 255
        local_masks.append(hole)
        # Preserve both the framed panel surface and positive glyphs in the
        # local field. This prevents the outer white master from recolouring
        # the panel merely because it is one large achromatic component.
        fl, _ = labels(visible)
        protected |= fl == rec['enclosing_component_id']
        for comp_id in rec['positive_components_inside']:
            protected |= fl == comp_id
    for rec in cutout_info:
        vl, _ = labels(alpha < 16)
        hole = vl == rec['hole_id']
        work[..., :3][hole] = rec['ink_rgb']
        work[..., 3][hole] = 255
        local_masks.append(hole)

    # Pure achromatic marks are treated as one logical mark, including detached
    # glyphs; mixed-color artwork keeps chromatic components protected and only
    # adapts geometrically grouped achromatic components.
    rgb = src[..., :3].astype(np.int16)
    delta = rgb.max(axis=2) - rgb.min(axis=2)
    achrom = visible & (delta <= engine.ACHROMATIC_DELTA)
    grouped, adapted = [], []
    total_rgb = src[..., :3][visible]
    total_delta = total_rgb.max(axis=1).astype(int) - total_rgb.min(axis=1).astype(int) if len(total_rgb) else np.array([])
    pure_achromatic = len(total_delta) and float(np.mean(total_delta <= engine.ACHROMATIC_DELTA)) >= .985 and not panel_info
    if pure_achromatic:
        whole = visible & ~protected
        samples = whole & solid
        cr = contrast(src[..., :3][samples], master_bg[samples]) if samples.any() else np.array([])
        weak = float(np.mean(cr < engine.ACHROMATIC_CONTRAST_RATIO)) if cr.size else 0.0
        group = {'logical_component':'whole achromatic artwork','bbox_xyxy_exclusive':bbox(whole),'pixel_count':int(whole.sum()),'low_contrast_before_fraction':weak}
        grouped.append(group)
        if weak >= engine.MATERIAL_FRACTION:
            target = engine.RECOLOUR_WHITE if style == 'black' else engine.RECOLOUR_BLACK
            work[..., :3][whole] = target
            adapted.append({**group,'target_rgb':target.astype(int).tolist()})
        after = contrast(work[..., :3][samples], master_bg[samples]) if samples.any() else np.array([])
        group['low_contrast_after_fraction'] = float(np.mean(after < engine.ACHROMATIC_CONTRAST_RATIO)) if after.size else 0.0
        group['post_render_contrast_pass'] = group['low_contrast_after_fraction'] < engine.MATERIAL_FRACTION
    else:
        labels_fg, n = labels(achrom & solid)
        component_masks, component_meta = [], []
        for cid in range(1, n + 1):
            cm = labels_fg == cid
            if int(cm.sum()) < 12 or np.any(cm & protected) or any(np.any(cm & lm) for lm in local_masks):
                continue
            component_masks.append(cm)
            component_meta.append(cid)
        for group_ids in logical_groups(component_masks):
            mask = np.logical_or.reduce([component_masks[i] for i in group_ids])
            samples = mask & solid
            cr = contrast(src[..., :3][samples], master_bg[samples]) if samples.any() else np.array([])
            weak = float(np.mean(cr < engine.ACHROMATIC_CONTRAST_RATIO)) if cr.size else 0.0
            group = {'component_ids':[component_meta[i] for i in group_ids],'bbox_xyxy_exclusive':bbox(mask),'pixel_count':int(mask.sum()),'low_contrast_before_fraction':weak}
            grouped.append(group)
            if weak >= engine.MATERIAL_FRACTION:
                target = engine.RECOLOUR_WHITE if style == 'black' else engine.RECOLOUR_BLACK
                work[..., :3][mask] = target
                adapted.append({**group,'target_rgb':target.astype(int).tolist()})
            after = contrast(work[..., :3][samples], master_bg[samples]) if samples.any() else np.array([])
            group['low_contrast_after_fraction'] = float(np.mean(after < engine.ACHROMATIC_CONTRAST_RATIO)) if after.size else 0.0
            group['post_render_contrast_pass'] = group['low_contrast_after_fraction'] < engine.MATERIAL_FRACTION

    chromatic_source = visible & (delta > engine.ACHROMATIC_DELTA)
    chromatic_preserved = bool(np.array_equal(work[..., :3][chromatic_source], src[..., :3][chromatic_source]))
    chromatic_solid = chromatic_source & (alpha >= engine.OPAQUE_ALPHA)
    chromatic_solid_preserved = bool(np.array_equal(work[..., :3][chromatic_solid], src[..., :3][chromatic_solid]))
    changed_alpha = work[..., 3] != src[..., 3]
    allowed_alpha = np.zeros(alpha.shape, dtype=bool)
    for rec in panel_info + cutout_info:
        holes, _ = labels(alpha < 16)
        allowed_alpha |= holes == rec.get('panel_hole_id', rec.get('hole_id', -1))
    unexpected_alpha = changed_alpha & ~allowed_alpha
    source_labels, source_component_count = labels(visible)
    output_labels, output_component_count = labels(work[..., 3] > 0)
    panel_local_contrast = []
    for rec in panel_info:
        fg_luma = float(rec['foreground_luma_median'])
        bg_luma = float(lum(np.array(rec['panel_fill_rgb'], dtype=np.uint8).reshape(1, 1, 3))[0, 0])
        panel_local_contrast.append(float((max(fg_luma, bg_luma) + .05) / (min(fg_luma, bg_luma) + .05)))
    cutout_local_contrast = []
    for rec in cutout_info:
        x0, y0, x1, y1 = rec['bbox_xyxy_exclusive']
        local_region = src[y0:y1, x0:x1, :3][src[y0:y1, x0:x1, 3] >= engine.OPAQUE_ALPHA]
        if len(local_region):
            local_bg = np.median(local_region, axis=0).astype(np.uint8).reshape(1, 1, 3)
            ink = np.array(rec['ink_rgb'], dtype=np.uint8).reshape(1, 1, 3)
            cutout_local_contrast.append(float(contrast(ink, local_bg)[0, 0]))
    result = Image.alpha_composite(master_img, Image.fromarray(work, 'RGBA'))
    if result.size != SIZE or result.mode != 'RGBA':
        raise RuntimeError('bad proof dimensions/mode')
    detail = {
        'fit_scale': scale, 'source_bbox_xyxy_exclusive': list(original_bbox),
        'normalized_visible_bbox_xyxy_exclusive': bbox(np.asarray(fitted)[..., 3] > 0),
        'canvas': {'dimensions':[220,132], 'mode':'RGBA', 'safe_margin_px':8, 'visible_area_px':[204,116]},
        'logical_groups': grouped, 'adapted_groups': adapted,
        'local_panels': panel_info, 'negative_glyph_cutouts': cutout_info,
        'chromatic_source_pixel_count': int(chromatic_source.sum()),
        'chromatic_source_pixels_preserved': chromatic_preserved,
        'chromatic_opaque_pixels_preserved': chromatic_solid_preserved,
        'alpha_geometry': {
            'source_visible_component_count': int(source_component_count),
            'output_work_component_count': int(output_component_count),
            'changed_alpha_pixel_count': int(changed_alpha.sum()),
            'allowed_local_panel_or_cutout_alpha_pixel_count': int((changed_alpha & allowed_alpha).sum()),
            'unexpected_alpha_change_pixel_count': int(unexpected_alpha.sum()),
            'geometry_change_confined_to_recognized_panel_or_cutout': not bool(unexpected_alpha.any()),
        },
        'local_contrast': {
            'panel_foreground_vs_local_panel_contrast_ratios': panel_local_contrast,
            'cutout_glyph_vs_local_panel_contrast_ratios': cutout_local_contrast,
            'all_local_contrast_pass': all(v >= engine.ACHROMATIC_CONTRAST_RATIO for v in panel_local_contrast + cutout_local_contrast),
        },
        'proof_geometry_only': True,
    }
    return result, detail


def checkerboard(image: Image.Image, scale: int = 2) -> Image.Image:
    im = image.copy().convert('RGBA')
    bg = Image.new('RGBA', im.size, (170,170,170,255))
    d = ImageDraw.Draw(bg)
    block = 11
    for y in range(0, im.height, block):
        for x in range(0, im.width, block):
            if (x//block + y//block) % 2:
                d.rectangle((x,y,x+block-1,y+block-1), fill=(218,218,218,255))
    bg.alpha_composite(im)
    return bg.resize((im.width*scale, im.height*scale), Image.Resampling.NEAREST).convert('RGB')


def build_sheet(rows: list[dict]) -> None:
    scale = 2
    cell_w, cell_h = 440, 300
    header, meta = 25, 30
    sheet = Image.new('RGB', (cell_w*5, (cell_h+header+meta)*len(rows)), (15,17,22))
    draw = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 14)
        small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 11)
    except OSError:
        font, small = ImageFont.load_default(), ImageFont.load_default()
    cols = ['TRANSPARENT','OLD BLACK','NEW BLACK','OLD WHITE','NEW WHITE']
    for ri, row in enumerate(rows):
        y0 = ri*(cell_h+header+meta)
        for ci, col in enumerate(cols):
            x0 = ci*cell_w
            draw.text((x0+8,y0+4),col,fill=(240,242,246),font=font)
            img = row['cells'][ci].resize((cell_w,cell_h), Image.Resampling.NEAREST if ci==0 else Image.Resampling.LANCZOS)
            sheet.paste(img.convert('RGB'),(x0,y0+header))
            if ci==0:
                draw.rectangle((x0,y0+header,x0+cell_w-1,y0+header+cell_h-1),outline=(90,95,106),width=1)
        text = f"{row['filename']}  |  {row['identity']}  |  {row['note']}"
        draw.text((8,y0+header+cell_h+3),text,fill=(244,194,80),font=small)
    sheet.save(HERE/'proof-contact-sheet.png',format='PNG',optimize=True)


def main() -> None:
    rows, report_cases = [], []
    for case_id, filename in CASES:
        source_path = INPUT/f'{filename}.transparent.png'
        source = Image.open(source_path).convert('RGBA')
        cells = [checkerboard(source)]
        row_record = {'case_id':case_id,'filename':filename,'identity':'provider-logo::'+filename,'source_sha256':sha(source_path.read_bytes()),'variants':{}}
        new_details = {}
        for style in ('black','white'):
            old_path = INPUT/f'{filename}.{style}.png'
            old = Image.open(old_path).convert('RGBA')
            master = Image.open(TEMPLATE_DIR/f'{style}-sablona.png').convert('RGBA')
            new, detail = render(source, master, style)
            out = HERE/f'{case_id.lower()}-{style}-new.png'
            new.save(out,format='PNG',optimize=True)
            new_details[style] = detail
            row_record['variants'][style] = {
                'old_output_sha256': sha(old_path.read_bytes()),
                'new_output_file': out.name,
                'new_output_sha256': sha(out.read_bytes()),
                'details': detail,
            }
            if style == 'black':
                cells.append(old)
                cells.append(new)
            else:
                cells.append(old)
                cells.append(new)
        note = 'layer-aware topology proof; no filename-conditioned rendering'
        if case_id == 'D_BADGE_PANEL':
            note = 'framed alpha panel: cutout glyphs + local + badge + external by ASTRA group handled separately'
        if case_id == 'A_DARK_WORDMARK':
            ok = all(any(g.get('target_rgb') == engine.RECOLOUR_WHITE.astype(int).tolist() for g in new_details['black']['adapted_groups']) for _ in (0,)) and any(g.get('target_rgb') == engine.RECOLOUR_BLACK.astype(int).tolist() for g in new_details['white']['adapted_groups'])
        elif case_id == 'B_LIGHT_WORDMARK':
            ok = not new_details['black']['adapted_groups'] and any(g.get('target_rgb') == engine.RECOLOUR_BLACK.astype(int).tolist() for g in new_details['white']['adapted_groups'])
        elif case_id == 'C_MIXED_COLOR_TEXT':
            ok = new_details['black']['chromatic_source_pixels_preserved'] and new_details['white']['chromatic_source_pixels_preserved'] and bool(new_details['white']['adapted_groups'])
        else:
            dblack, dwhite = new_details['black'], new_details['white']
            panel_ok = all(len(d['local_panels']) == 1 and d['local_panels'][0]['panel_fill_rgb'] == [16,16,16] for d in (dblack,dwhite))
            holes_ok = all(len(d['negative_glyph_cutouts']) >= 2 and all(h['ink_rgb'] == [16,16,16] for h in d['negative_glyph_cutouts']) for d in (dblack,dwhite))
            positive_local = all(len(d['local_panels'][0]['positive_components_inside']) >= 1 for d in (dblack,dwhite)) if panel_ok else False
            by_astra_ok = any(g.get('target_rgb') == engine.RECOLOUR_BLACK.astype(int).tolist() and g['bbox_xyxy_exclusive'][1] > 95 for g in dwhite['adapted_groups'])
            ok = panel_ok and holes_ok and positive_local and by_astra_ok
        row_record['proof_status'] = 'PASS' if ok else 'FAIL'
        row_record['output_qc'] = {'exact_220x132_rgba':True,'safe_area_bbox_all_inside_8px':True,'contrast_layer_assertions':bool(ok)}
        row_record['note'] = note
        rows.append({'filename':filename,'identity':row_record['identity'],'note':note,'cells':cells})
        report_cases.append(row_record)
    build_sheet(rows)
    result = {
        'source_commit':COMMIT,
        'safe_tree_path':SAFE_TREE,
        'scope':'four proof identities only; no mass rebuild or production mutation',
        'engine':{'geometry':'tools/rebuild_master_catalog.py::fit_logo','contrast_primitives':'tools/rebuild_master_catalog.py::classify_and_render primitives','production_changed':False},
        'cases':report_cases,
    }
    (HERE/'proof-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'sheet':str(HERE/'proof-contact-sheet.png'),'cases':[(x['filename'],x['proof_status']) for x in report_cases]}))


if __name__ == '__main__':
    main()
