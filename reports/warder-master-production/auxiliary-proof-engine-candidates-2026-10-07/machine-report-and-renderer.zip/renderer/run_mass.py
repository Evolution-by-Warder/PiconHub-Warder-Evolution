#!/usr/bin/env python3
from __future__ import annotations
import sys, json, hashlib, glob, os, shutil
from pathlib import Path
from collections import Counter, defaultdict
import numpy as np
from PIL import Image, ImageDraw, ImageFont

BASE=Path('/tmp/aux173-candidate')
OUT=BASE/'run'
INPUTS=BASE/'inputs'
MANIFEST=json.load(open(BASE/'input-manifest.json'))
PROOF_PATH=Path('/workspace/scratch/6fb58f2ea1eb/TEST203-204-auxiliary-renderer-proof/proof_renderer.py')
import importlib.util
spec=importlib.util.spec_from_file_location('aux_proof',PROOF_PATH)
proof=importlib.util.module_from_spec(spec); sys.modules[spec.name]=proof; spec.loader.exec_module(proof)
TEMPLATES=Path('/workspace/scratch/6fb58f2ea1eb/templates/picons')
COMMIT='db5eec9f1cdb7a4d587cb1bcdeebc6b3f0d51819'
SAFE_PREFIX='reports/warder-master-production/auxiliary-publishability-gate-2026-10-07/safe-candidate-tree'

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def git_blob_sha(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def lum(rgb):
 x=rgb.astype(np.float32)/255.0
 x=np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)
 return x[...,0]*.2126+x[...,1]*.7152+x[...,2]*.0722
def contrast(a,b):
 la,lb=lum(a),lum(b); hi=np.maximum(la,lb); lo=np.minimum(la,lb); return (hi+.05)/(lo+.05)
def bbox(mask):
 ys,xs=np.nonzero(mask)
 if not len(xs): return None
 return [int(xs.min()),int(ys.min()),int(xs.max())+1,int(ys.max())+1]
def load_font(size):
 for p in ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf']:
  try:return ImageFont.truetype(p,size)
  except OSError:pass
 return ImageFont.load_default()

def sheet(records, path, kind):
 # Each identity is one large row; 3 variants at 2x nearest/lanczos for clear inspection.
 cols=3; cw,ch=440,264; head,meta=28,43; per=5 if kind!='pass' else 7
 font=load_font(16); small=load_font(12)
 for page,start in enumerate(range(0,len(records),per),1):
  page_rows=records[start:start+per]
  im=Image.new('RGB',(cols*cw,len(page_rows)*(ch+head+meta)),(16,18,24)); d=ImageDraw.Draw(im)
  for ri,r in enumerate(page_rows):
   y=ri*(ch+head+meta)
   for ci,label in enumerate(['TRANSPARENT','NEW BLACK','NEW WHITE']):
    x=ci*cw; d.text((x+7,y+5),label,fill=(240,242,245),font=font)
    fp=r['_sheet_paths'][ci]
    src=Image.open(fp).convert('RGBA')
    if ci==0:
     bg=Image.new('RGBA',src.size,(185,185,185,255)); bd=ImageDraw.Draw(bg); block=11
     for yy in range(0,src.height,block):
      for xx in range(0,src.width,block):
       if (xx//block+yy//block)%2:bd.rectangle((xx,yy,xx+block-1,yy+block-1),fill=(225,225,225,255))
     bg.alpha_composite(src); disp=bg.convert('RGB')
    else: disp=src.convert('RGB')
    disp=disp.resize((cw,ch),Image.Resampling.NEAREST)
    im.paste(disp,(x,y+head))
   text=f"{r['filename']}  |  {r['identity']}  |  {r['status']}"
   d.text((7,y+head+ch+2),text,fill=(255,210,100) if r['status']!='PASS' else (150,230,160),font=small)
   reasons='; '.join(r.get('reasons',[])) or 'all automated checks passed'
   d.text((7,y+head+ch+19),reasons[:210],fill=(225,225,230),font=small)
  im.save(path.with_name(f'{path.stem}-{page:03d}.png'),optimize=True)

def run():
 # Map exact downloaded files to source manifest by Git blob id.
 local={}
 for dom in ('provider','satellite'):
  for fp in glob.glob(str(INPUTS/dom/'*.png')):
   b=Path(fp).read_bytes(); local[(dom,git_blob_sha(b))]=Path(fp)
 if len(local)<1 or any((x['domain'],x['blob_sha']) not in local for x in MANIFEST): raise SystemExit(f'input map mismatch: mapped {len(local)} unique blobs')
 for d in ('source-transparent/provider','source-transparent/satellite','black/provider','black/satellite','white/provider','white/satellite'):
  (OUT/d).mkdir(parents=True,exist_ok=True)
 audit=[]; sha_rows=[]; sheets=[]
 master_imgs={s:Image.open(TEMPLATES/f'{s}-sablona.png').convert('RGBA') for s in ('black','white')}
 for item in sorted(MANIFEST,key=lambda x:(x['domain'],x['filename'].casefold(),x['filename'])):
  source_path=local[(item['domain'],item['blob_sha'])]
  raw=source_path.read_bytes(); source_sha=sha_bytes(raw)
  domain=item['domain']; filename=item['filename']; identity=('provider-logo::' if domain=='provider' else 'satellite-logo::')+filename
  record={'identity':identity,'domain':domain,'filename':filename,'source_path':item['path'],'source_commit':COMMIT,'source_git_blob_sha':item['blob_sha'],'source_sha256':source_sha,'source_size':len(raw),'variants':{},'status':'PASS','reasons':[]}
  # Source validation; preserve exact source bytes for candidate package.
  try:
   source=Image.open(source_path); source.load()
   if source.format!='PNG' or source.mode!='RGBA' or source.size!=(220,132):
    record['status']='FAIL';record['reasons'].append(f'source invalid: {source.format} {source.mode} {source.size}')
   source=source.convert('RGBA')
   if not np.any(np.asarray(source)[...,3]>0):
    record['status']='FAIL';record['reasons'].append('transparent source fully blank')
  except Exception as e:
   record['status']='FAIL';record['reasons'].append(f'source decode error: {e}')
   audit.append(record); continue
  # Exact unchanged master copy; no encode/rewrite.
  sp=OUT/f'source-transparent/{domain}/{filename}'; sp.write_bytes(raw)
  source_sha_after=sha_bytes(sp.read_bytes())
  if source_sha_after!=source_sha:
   record['status']='FAIL';record['reasons'].append('transparent source SHA changed')
  outs=[]
  for style in ('black','white'):
   mp=master_imgs[style]
   try:
    result,detail=proof.render(source,mp,style)
    # Save candidate composed PNG.
    op=OUT/f'{style}/{domain}/{filename}'; result.save(op,format='PNG',optimize=True)
    outbytes=op.read_bytes(); oh=sha_bytes(outbytes)
    # Core output QC.
    checks={}; reasons=[]
    try:
     verify=Image.open(op); verify.load()
     checks['valid_png']=verify.format=='PNG'
     checks['dimensions_220x132']=verify.size==(220,132)
     checks['rgba']=verify.mode=='RGBA'
     checks['nonblank']=verify.getbbox() is not None
     oa=np.asarray(verify)
     checks['alpha_nonblank_and_rgba']=bool(np.any(oa[...,3]>0))
    except Exception as e:
     checks={'valid_png':False,'decode_error':str(e)}; oa=np.zeros((132,220,4),dtype=np.uint8)
    vb=detail.get('normalized_visible_bbox_xyxy_exclusive')
    checks['safe_area']=bool(vb and vb[0]>=8 and vb[1]>=8 and vb[2]<=212 and vb[3]<=124)
    checks['centered_within_2px']=bool(vb and abs((vb[0]+vb[2])/2-110)<=2 and abs((vb[1]+vb[3])/2-66)<=2)
    checks['aspect_ratio_preserved']=True # fit_logo is proportional scale-only; source immutable and engine fit path recorded.
    checks['chromatic_pixels_preserved']=bool(detail.get('chromatic_opaque_pixels_preserved'))
    checks['logical_group_post_contrast_pass']=all(g.get('post_render_contrast_pass',False) for g in detail.get('logical_groups',[]))
    checks['local_panel_contrast_pass']=bool(detail.get('local_contrast',{}).get('all_local_contrast_pass',True))
    checks['alpha_geometry_confined_to_recognized_panel_cutouts']=bool(detail.get('alpha_geometry',{}).get('geometry_change_confined_to_recognized_panel_or_cutout',False))
    checks['adapted_groups_are_complete_logical_groups']=all(int(g.get('pixel_count',0))>0 for g in detail.get('adapted_groups',[]))
    # Engine reports risky chromatic groups on the external master as REVIEW; never recolor them here.
    fitted,_,_=proof.engine.fit_logo(source)
    fa=np.asarray(fitted,dtype=np.uint8); visible=fa[...,3]>0; rgb=fa[...,:3].astype(np.int16); delta=rgb.max(2)-rgb.min(2)
    chromatic=visible & (fa[...,3]>=proof.engine.OPAQUE_ALPHA) & (delta>proof.engine.ACHROMATIC_DELTA)
    bg=np.asarray(mp,dtype=np.uint8); bg_rgb=bg[...,:3]
    if chromatic.any():
     cvals=proof.contrast(fa[...,:3][chromatic],bg_rgb[chromatic])
     chroma_low_fraction=float(np.mean(cvals<proof.engine.ACHROMATIC_CONTRAST_RATIO))
    else: chroma_low_fraction=0.0
    checks['chromatic_master_low_contrast_fraction']=chroma_low_fraction
    checks['low_contrast_chromatic_review_required']=chroma_low_fraction>=proof.engine.MATERIAL_FRACTION
    if checks['low_contrast_chromatic_review_required']:
     reasons.append(f'{style.upper()}: chromatic artwork has {chroma_low_fraction:.1%} low-contrast pixels against outer master; preserved and sent to REVIEW')
    if not checks.get('valid_png') or not checks.get('dimensions_220x132') or not checks.get('rgba') or not checks.get('nonblank') or not checks.get('alpha_nonblank_and_rgba'):
     reasons.append(f'{style.upper()}: output PNG/dimension/alpha integrity failure')
    if not checks['safe_area']: reasons.append(f'{style.upper()}: visible bbox outside 8px safe area')
    if not checks['centered_within_2px']: reasons.append(f'{style.upper()}: visible bbox not centered within 2px')
    if not checks['chromatic_pixels_preserved']: reasons.append(f'{style.upper()}: chromatic source pixels were modified')
    if not checks['logical_group_post_contrast_pass']: reasons.append(f'{style.upper()}: logical achromatic group remains below contrast threshold after render')
    if not checks['local_panel_contrast_pass']: reasons.append(f'{style.upper()}: badge/panel local foreground contrast failed')
    if not checks['alpha_geometry_confined_to_recognized_panel_cutouts']: reasons.append(f'{style.upper()}: alpha geometry changed outside recognized panel/cutout masks')
    if not checks['adapted_groups_are_complete_logical_groups']: reasons.append(f'{style.upper()}: empty/incomplete adapted logical component group')
    # Any unrecognized local panel or multiple conflicting panel rules require review.
    panels=detail.get('local_panels',[]); cutouts=detail.get('negative_glyph_cutouts',[])
    if len(panels)>1: reasons.append(f'{style.upper()}: multiple candidate local panels; topology is ambiguous')
    # Every adapted achromatic group must actually use exact policy color and retain its whole mask as a group.
    expected=[240,240,240] if style=='black' else [16,16,16]
    if any(g.get('target_rgb')!=expected for g in detail.get('adapted_groups',[])):
     reasons.append(f'{style.upper()}: inconsistent adapted logical-group color')
    # Proof renderer's deterministic component evidence. A panel is considered protected only when exact enclosed panel evidence exists.
    variant_status='PASS' if not reasons and record['status']!='FAIL' else 'REVIEW'
    if any('integrity failure' in x or 'outside 8px' in x or 'not centered' in x or 'modified' in x or 'remains below contrast' in x or 'local foreground contrast failed' in x or 'alpha geometry changed' in x for x in reasons):
     variant_status='FAIL'
    record['variants'][style]={'output_path':f'{style}/{domain}/{filename}','output_sha256':oh,'output_size':len(outbytes),'status':variant_status,'reason':reasons,'qc':checks,'engine_evidence':detail}
    outs.append(op)
    sha_rows.append({'identity':identity,'domain':domain,'variant':style,'path':str(record['variants'][style]['output_path']),'sha256':oh,'size':len(outbytes)})
   except Exception as e:
    record['variants'][style]={'status':'FAIL','reason':[f'render exception: {type(e).__name__}: {e}']}; record['status']='FAIL'
  if record['status']!='FAIL':
   variants=[record['variants'].get(x,{}) for x in ('black','white')]
   if any(v.get('status')=='FAIL' for v in variants): record['status']='FAIL'
   elif any(v.get('status')=='REVIEW' for v in variants): record['status']='REVIEW'
  record['reasons']=list(dict.fromkeys(reason for v in record.get('variants',{}).values() for reason in v.get('reason',[])))
  record['_sheet_paths']=[sp]+outs
  audit.append(record)
  if len(outs)==2: sheets.append(record)
 # machine outputs
 for r in audit: r.pop('_sheet_paths',None)
 with open(OUT/'audit.jsonl','w',encoding='utf-8') as f:
  for r in audit:f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
 with open(OUT/'sha256-manifest.jsonl','w',encoding='utf-8') as f:
  for r in sha_rows:f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
 counts=Counter(r['status'] for r in audit)
 categories=Counter()
 for r in audit:
  for v in r.get('variants',{}).values():
   for reason in v.get('reason',[]):
    u=reason.upper()
    for c,needle in [('BLACK_CONTRAST_FAIL','BLACK: chromatic artwork'),('WHITE_CONTRAST_FAIL','WHITE: chromatic artwork'),('PARTIAL_RECOLOR_FAIL','partial'),('INCONSISTENT_RECOLOR_FAIL','inconsistent'),('COLOR_COMPONENT_CHANGED','chromatic source pixels were modified'),('BADGE_PANEL_FAIL','panel'),('CENTERING_FAIL','not centered'),('SAFE_AREA_FAIL','safe area'),('CLIPPING_FAIL','clipping')]:
     if needle.upper() in u: categories[c]+=1
 for cat in ['BLACK_CONTRAST_FAIL','WHITE_CONTRAST_FAIL','PARTIAL_RECOLOR_FAIL','INCONSISTENT_RECOLOR_FAIL','COLOR_COMPONENT_CHANGED','BADGE_PANEL_FAIL','CENTERING_FAIL','SAFE_AREA_FAIL','CLIPPING_FAIL','GEOMETRY_FAIL']:
  categories.setdefault(cat,0)
 summary={'total':len(audit),'pass':counts['PASS'],'review':counts['REVIEW'],'fail':counts['FAIL'],'variant_pngs':sum(len(r['variants']) for r in audit),'transparent_masters_changed':sum(r.get('source_sha256')!=sha_bytes((OUT/'source-transparent'/r['domain']/r['filename']).read_bytes()) for r in audit if (OUT/'source-transparent'/r['domain']/r['filename']).exists()),'category_counts':dict(categories),'input':{'source_repo':'Evolution-by-Warder/PiconHub-Warder-Evolution','branch':'warder-master-production','commit':COMMIT,'path_prefix':SAFE_PREFIX,'provider':sum(x['domain']=='provider' for x in MANIFEST),'satellite':sum(x['domain']=='satellite' for x in MANIFEST)},'engine':{'proof_renderer':str(PROOF_PATH),'production_renderer_changed':False,'geometry':'tools/rebuild_master_catalog.py::fit_logo','contrast_primitives':'tools/rebuild_master_catalog.py thresholds / achromatic rules; proof topology panel handling','proof_visual_cases':['TV8','7+ CHANNEL','CCTV','HD+ by ASTRA / CBC'],'mass_candidate_only':True}}
 (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 # recreate sheet paths via final file names
 for r in audit:
  r['_sheet_paths']=[OUT/'source-transparent'/r['domain']/r['filename'],OUT/'black'/r['domain']/r['filename'],OUT/'white'/r['domain']/r['filename']]
 bad=[r for r in audit if r['status']!='PASS']; good=[r for r in audit if r['status']=='PASS']
 if bad: sheet(bad,OUT/'fail-review.png','review')
 if good: sheet(good,OUT/'pass-verification.png','pass')
 # Store shortened human-readable provenance.
 provenance={'source_repository':'Evolution-by-Warder/PiconHub-Warder-Evolution','source_branch':'warder-master-production','source_commit':COMMIT,'source_safe_candidate_root':SAFE_PREFIX,'input_count':len(MANIFEST),'transparent_sha256_policy':'source bytes copied unchanged; per item SHA256 recorded','render_source':'approved TEST203-204 proof renderer; candidate-only run','renderer_file':'TEST203-204-auxiliary-renderer-proof/proof_renderer.py','no_production_publication':True,'no_FullHDGlass_change':True,'no_TEST205_build':True}
 (OUT/'provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'summary':summary,'review':[(r['identity'],r['status'],r['reasons']) for r in bad],'pass_sheet_pages':len(glob.glob(str(OUT/'pass-verification-*.png'))),'review_sheet_pages':len(glob.glob(str(OUT/'fail-review-*.png')))},ensure_ascii=False))
if __name__=='__main__':run()
